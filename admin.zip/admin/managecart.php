<?php
session_start();

if(isset($_SESSION['usersession']))
{
    if(isset($_POST['cart'])){
        if(isset($_SESSION['cart'])){
            $pidd=array_column($_SESSION['cart'],'id');

        
            if(in_array($_POST['hid'],$pidd)){
                echo'<script>alert("Product  Already Exits"); window.location.'.$_SESSION['pagestate'].';</script>';
            }
            else
            {
                $c=count($_SESSION['cart']);
                $_SESSION['cart'][$c]=array('id'=>$_POST['hid'],
                'name'=>$_POST['hname'],
                'des'=>$_POST['hdes'],
                'qty'=>$_POST['hqty'],
                'price'=>$_POST['hprice'],
                'img'=>$_POST['himages'],
                'pow'=>$_POST['hpower']
                );
                echo'<script>alert("Product added"); window.location.'.$_SESSION['pagestate'].';</script>';
            }
        }
        else{
                $_SESSION['cart'][0]=array('id'=>$_POST['hid'],
                'name'=>$_POST['hname'],
                'des'=>$_POST['hdes'],
                'qty'=>$_POST['hqty'],
                'price'=>$_POST['hprice'],
                'img'=>$_POST['himages'],
                'pow'=>$_POST['hpower']
                );
                echo'<script>alert("Product added"); window.location.'.$_SESSION['pagestate'].';</script>';
            }
    // print_r($_SESSION['cart']);
    }   
}
else{
    echo'<script>alert("firstly you have to login"); window.location.href="./login.php";</script>';
}
?>