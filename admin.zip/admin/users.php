<?php require_once ("head.php") ?>
<?php require_once("../phpcode/confi.php")?>
<link rel="stylesheet" href="../css/bootstrap.min.css">
<script src="../js/bootstrap.bundle.min.js"></script>
<?php
if(isset($_POST['udelete'])){
  $uid=$_POST['uid'];
  $sql2='DELETE FROM users WHERE userid='.$uid.'';
    $res2=mysqli_query($con,$sql2);
    if(!$res2){
        echo "<script> alert('User Not Removed')</script>";
    }else{
        echo "<script> alert('User Removed Succesfully')</script>";
    }
}
?>

<style>
  body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
  }

  .container {
    width: 100%;
    /* min-height:100vh; */
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 50px 8%;
    position: absolute;
    top: -6%;
    right: -5%;
    height: 100%;
    width: 100%;
  }

  .table {
    background-color: white;
    border-collapse: collapse;
    width: 100%;
    max-width: 800px;
    right: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  .table th,
  .table td {
    padding: 12px 15px;
    text-align: left;
  }

  .table th {
    background-color: #f0f0f0;
  }

  .table tbody tr:nth-child(even) {
    background-color: #f8f8f8;
  }

  .table tbody tr:hover {
    background-color: #e0e0e0;
  }

  a {
    color: #007bff;
    text-decoration: none;
    margin-right: 10px;
  }
</style>

<div class="container">
  <main>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Id</th>
          <th scope="col">Name</th>
          <th scope="col">Email</th>
          <th scope="col">Password</th>
        </tr>
      </thead>
      <tbody>
        <?php
                $sql1= "select * from users";
                $res = mysqli_query($con,$sql1);
                if(mysqli_num_rows($res) > 0){
                  foreach($res as $row)
                  {
                    // echo $row['userid']
                    ?>
        <tr>
          <td>
            <?php echo $row['userid'];?>
          </td>
          <td>
            <?php echo $row['username'];?>
          </td>
          <td>
            <?php echo $row['email'];?>
          </td>
          <td>
            <?php echo $row['password'];?>
          </td>
          <td>
            <!-- <a href="" class="btn btn-danger btn-small">Delete</a> -->
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
              <input type="hidden" name="uid" value="<?php echo $row['userid']; ?>">
              <button type="submit" class="btn btn-danger" name="udelete">Delete</button>
            </form>
          </td>
        </tr>
        <?php
                  }
                }
                else{
                  echo "No Records Found";
                }
            ?>

      </tbody>
    </table>
  </main>
</div>

<?php require_once ("foot.php") ?>