<?php require_once ("head.php") ?>
<?php include '../phpcode/confi.php'; ?>

<?php

$msg1 = '';
if (isset($_POST['change'])) {
    $n = $_POST['nm'];
    $c = $_POST['cat'];
    $p = $_POST['pric'];
    $q = $_POST['qty'];
    $d = $_POST['des'];
    $pid = $_POST['pid'];
  
    $filenm = $_FILES['file1']['name'];
    $basenm = substr($filenm, 0, strripos($filenm, '.'));
    $ext = substr($filenm, strripos($filenm, '.'));
    $tmpnm = $_FILES['file1']['tmp_name'];
    $alowtyp = array(".jpg", ".png");
    if (in_array($ext, $alowtyp)) {
        $newfilenm = md5($basenm) . rand(10, 1000) . time() . $ext;
        if (file_exists("upload/" . $newfilenm)) {
            echo "file existst";
        } else {
            move_uploaded_file($tmpnm, "upload/" . $newfilenm);
            if ($n != "" && $c != "" && $p != "" && $q != "" && $d != "" ) {
                $ip = "UPDATE products SET pname='$n',category='$c',price='$p',proimages='$newfilenm',qty='$q',des='$d' WHERE pid='$pid'";
                $r = mysqli_query($con, $ip);
                if ($r) {
                    echo "<script> alert('Product Edited Sccesffully')</script>";
                } else {
                    $msg1 = "Edit FAILED";
                    echo $msg1.mysqli_error($con);
                }
            } else {
                $msg1 = "fiels is empty";
                echo $msg1;
            }
        }
    }
}

?>
<!-- Delete -->
<?php
if (isset($_POST['remove'])) {
    $pid = $_POST['pid'];
    $ss = 'DELETE FROM products WHERE pid=' . $pid . '';
    $rem = mysqli_query($con, $ss);
    if (!$rem) {
        echo "<script> alert('Product Not Removed')</script>";
    } else {
        echo "<script> alert('Product Removed Succesfully')</script>";
    }
}

?>
<style>
  body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
  }

  .container {
        width: 100%;
        /* min-height:100vh; */
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 50px 8%;
        position: absolute;
        top: -6%;
        right: -14%;
        height: 100%;
        width: 100%;
    }

  .table {
    
    width: 100%;
    max-width: 800px;
    right: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  .table th,
  .table td {
    padding: 12px 15px;
    text-align: left;
  }

  .table th {
    background-color: #f0f0f0;
  }

  .table tbody tr:nth-child(even) {
    background-color: #f8f8f8;
  }

  .table tbody tr:hover {
    background-color: #e0e0e0;
  }

  a {
    color: #007bff;
    text-decoration: none;
    margin-right: 10px;
  }
</style>

<?php require_once("../phpcode/confi.php")?>
<div class="container">
<main>
  <h1><?php echo $msg1; ?></h1>
    <table class="table">
      <form action="<?php echo ($_SERVER['PHP_SELF']) ?>" method="post" enctype="multipart/form-data">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Name</th>
            <th scope="col">Category</th>
            <th scope="col">Price</th>
            <th scope="col">Quantity</th>

          </tr>
        </thead>
        <tbody>
            <?php
            $sr=0;
                $sql1= "select * from products";
                $res = mysqli_query($con,$sql1);
                if(mysqli_num_rows($res) > 0){
                  $i=0;
                  foreach($res as $row)
                  {
                    $sr++;
                    $i++;
                    // echo $row['userid']
                    ?>
                            <tr>
                              <td><?php echo $sr; ?></td>
                              <td><?php echo $row['pname'];?></td>
                              <td><?php echo $row['category'];?></td>
                              <td><?php echo $row['price'];?></td>
                              <td><?php echo $row['qty'];?></td>
                              <input type="hidden" name="pid" value="<?php echo $row['pid'];?>">
                              <td>
                                <a href="">Edit</a>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo $i; ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                                        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                                    </svg></button>
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal<?php echo $i; ?>" tabindex="-1" aria-labelledby="exampleModalLabel<?php echo $i; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel<?php echo $i; ?>">Modal title</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-center"><?php echo $msg1; ?></p>

                                                <div class="input-group mb-3">
                                                    <span class="input-group-text" id="basic-addon1">Name</span>
                                                    <input type="text" class="form-control" aria-label="Username" name="nm" aria-describedby="basic-addon1">
                                                </div>
                                                <div class="input-group mb-3">
                                                    <label class="input-group-text" for="inputGroupSelect01">Category</label>
                                                    <select class="form-select" id="inputGroupSelect01" name="cat">
                                                        <option selected>Choose...</option>
                                                        <option value="specs">Specs</option>
                                                        <option value="lens">Lense</option>
                                                        <option value="goggles">Goggles</option>
                                                        
                                                    </select>
                                                </div>
                                                
                                                <div class="input-group mb-3">
                                                    <span class="input-group-text">Price</span>
                                                    <input type="text" class="form-control" name="pric" aria-label="Username">
                                                    <span class="input-group-text">Quntity</span>
                                                    <input type="text" class="form-control" name="qty" aria-label="Server">
                                                </div>

                                                <div class="input-group mb-3">
                                                    <span class="input-group-text">Description</span>
                                                    <textarea class="form-control" aria-label="With textarea" name="des"></textarea>
                                                </div>
                                                <div class="input-group mb-3">
                                                    <label class="input-group-text" for="inputGroupFile01">Photo</label>
                                                    <!-- <input type="file" class="form-control" id="inputGroupFile01" name="file"> -->
                                                    <input type="file" name="file1" id="">
                                                  </div>
                                                

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" name="change" class="btn btn-primary">Save changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-danger" name="remove">Delete</button>
                              </td>
                            </tr>
                    <?php
                  }

                }
                else{
                  echo "No Records Found";
                }
            ?>
         
        </tbody>
        </form>
      </table>
</main>
</div>
<?php require_once ("foot.php") ?>
